package com.exilant.PriorityQueue;

import java.util.Scanner;

public class DisplayQuection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t = new Thread(new Runnable() {
			
			@Override
			public void run() {
				
				while (QuectionClient.quectionNumber < QuectionClient.questions.length){
					
					try {
						QuectionClient.displayQuection();
						Thread.sleep(3000);
					} catch (InterruptedException e) {
					
						continue;
					}
					
				}
				
				QuectionClient.displayResult();
			}
		});
		t.start();
		
		Scanner scan = new Scanner(System.in);
		int answerIndex = scan.nextInt();
		QuectionClient.setAnswer(answerIndex);
		t.interrupt();
		
	}

}
