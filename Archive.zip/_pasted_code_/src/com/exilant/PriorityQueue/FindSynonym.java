package com.exilant.PriorityQueue;

import java.util.HashMap;
import java.util.Scanner;

public class FindSynonym {

	public static void main(String[] args) {
		
		HashMap<String, String[]> synonym = new HashMap<String, String[]>();
		
		synonym.put("Beautiful", new String[]{"Attractive","Pretty","Lovely"});
		synonym.put("Fair", new String[]{"Just","Objective","Impartial"});
		synonym.put("Funny", new String[]{"Humorous","Comical","Hilarious","Hysterical"});
		synonym.put("Happy", new String[]{"Content","Joyful","Mirthful"});
		synonym.put("Hardworking", new String[]{"Diligent","Determined","Enterprising"});
		// We can take input from command line or by using scanner 
		Scanner scan = new Scanner(System.in);
		String name = scan.next();
		
		String[] synonyms = synonym.get(name);
		
		for (String temp:synonyms){
			
			System.out.println(temp);
		}
  
	}

}
