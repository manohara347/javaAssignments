package com.exilant.PriorityQueue;

public class Question {
	
	private String quection;
	private String answers[];
	private int currectAnsIndex = -1;
	
	public Question(String quection, String[] answers, int currectAnsIndex) {
		super();
		this.quection = quection;
		this.answers = answers;
		this.currectAnsIndex = currectAnsIndex;
	}

	public String getQuection() {
		return quection;
	}
	public String[] getAnswers() {
		return answers;
	}
	public int getCurrectAnsIndex() {
		return currectAnsIndex;
	}

}
