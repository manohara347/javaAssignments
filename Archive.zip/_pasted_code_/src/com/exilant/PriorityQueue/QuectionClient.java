package com.exilant.PriorityQueue;


public class QuectionClient {
	
	static Question questions[] = new Question[]{
			new Question("Which of the following statements should be used to obtain a remainder after dividing 3.14 by 2.1 ?", new String[]{"rem = 3.14 % 2.1","rem = modf(3.14, 2.1)","rem = fmod(3.14, 2.1)","Remainder cannot be obtain in floating point division."}, 3),
			new Question("What are the types of linkages?", new String[]{"Internal and External","External, Internal and None","External and None","Internal"}, 2),
			new Question("Which of the following special symbol allowed in a variable name?", new String[]{"* (asterisk)","| (pipeline)","- (hyphen)","_ (underscore)"}, 4),
			new Question("How would you round off a value from 1.66 to 2.0?", new String[]{"ceil(1.66)","loor(1.66)","roundup(1.66)","roundto(1.66)"}, 1)
			
	};
	static int quectionNumber = 0;
	static Question currentQuection;
	static int currectAnsCount = 0;
	static int wrongAnswerCount = 0;
	
	static  synchronized void displayQuection(){
		currentQuection = questions[quectionNumber];
		System.out.println((quectionNumber +1) +" "+ currentQuection.getQuection());
		System.out.println("1. " + currentQuection.getAnswers()[0]);
		System.out.println("2. " + currentQuection.getAnswers()[1]);
		System.out.println("3. "+ currentQuection.getAnswers()[2]);
		System.out.println("4. " + currentQuection.getAnswers()[3]);
		quectionNumber++;
	}
	
	static synchronized void setAnswer(int index){
		
		if (currentQuection.getCurrectAnsIndex() == index) {
			currectAnsCount++;
			System.out.println("Currect");
		} else {
			System.out.println("wrong answer");
			wrongAnswerCount++;
			System.out.println("wrong");
		}
	}
	
	static synchronized void displayResult(){
		
		System.out.println("Number of currect answers :" + currectAnsCount);
		System.out.println("Number of wrong answer count: "+ wrongAnswerCount);
	}
}
