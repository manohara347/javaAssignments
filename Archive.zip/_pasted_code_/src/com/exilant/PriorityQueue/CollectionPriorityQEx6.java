package com.exilant.PriorityQueue;

import java.util.Comparator;
import java.util.PriorityQueue;


/**
 *	program with priority queue which takes the user defined object and 
 *  displays based on sorter given in comparable and comparator 
 */

class Person implements Comparable<Person> {

	String name;
	int id;

	public Person(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}

	@Override
	public int compareTo(Person per) {
		// TODO Auto-generated method stub
		return getId() - per.getId();
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", id=" + id + "]";
	}

}


class PersonClient {

	PriorityQueue<Person> sortByName(PriorityQueue<Person> persons) {

		class sortName implements Comparator<Person> {

			@Override
			public int compare(Person per, Person per2) {
				// TODO Auto-generated method stub
				return per.getName().compareToIgnoreCase(per2.getName());
			}

		}	
		PriorityQueue<Person> temp = new PriorityQueue<Person>(new sortName());
		temp.addAll(persons);
		return  temp;
	}

	PriorityQueue<Person> sortById(PriorityQueue<Person> persons) {

		class sortId implements Comparator<Person>{

			@Override
			public int compare(Person per, Person per2) {
				// TODO Auto-generated method stub
				return per.getId() - per2.getId();
			}

		}	

		PriorityQueue<Person> temp = new PriorityQueue<Person>(new sortId());
		temp.addAll(persons);
		return  temp;
	}
}

public class CollectionPriorityQEx6 {


	static void print(PriorityQueue<Person> person){

		for(Person temp:person){

			System.out.println(temp);
		}

	}
	
	public static void main(String[] args) {

		PersonClient personClient = new PersonClient();

		PriorityQueue<Person> person = new PriorityQueue<Person>();

		person.offer(new Person("SowmyaShree",1));
		person.offer(new Person("Varsha",2));
		person.offer(new Person("Rishi",4));
		person.offer(new Person("ramesh",3));
		System.out.println("-------Sort by using comparable-------");
		print(person);
		System.out.println("-----------Sort by Name using comparable--------");
		person = personClient.sortByName(person);
		print(person);
		System.out.println("-----------Sort by Id using comparable--------");
		person = personClient.sortById(person);
		print(person);
	}
}
