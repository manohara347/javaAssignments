package com.exilant.dao;

import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import com.exilant.beans.Customer;
import com.exilant.connection.GetConnection;
import com.exilant.interfaces.ICandidateDAO;
public class CandidateDAO implements ICandidateDAO{

	@Override
	public List<Customer> getAllCustomersOfCity(String city) {
		// TODO Auto-generated method stub
		
		 //cust_id, cust_first_name, cust_last_name,cust_sal,cust_email,house_number,street,city,pin 
		GetConnection gc = new GetConnection();
		String sql ="SELECT * FROM Customer where city = ?";  // = for exact match
		
		try {
			
			gc.ps = GetConnection.getOracleConn().prepareStatement(sql);
			gc.ps.setString(1, city);
			
			gc.rs = gc.ps.executeQuery();
			ArrayList<Customer> customer = new ArrayList<Customer>();
			// this starts from -1 
			while(gc.rs.next()){
				
				Customer cust = new Customer();
				cust.setCustId(gc.rs.getInt(1));
				cust.setName(cust.new Name(gc.rs.getString(2),gc.rs.getString(3)));
				cust.setIncome(gc.rs.getDouble(4));
				cust.setEmail(gc.rs.getString(5));
				
				int hNo = gc.rs.getInt(6);
				String street = gc.rs.getString(7);
				String cityCandidate = gc.rs.getString(8);
				int pin = gc.rs.getInt(9);
				
				cust.setAddr(cust.new Address(hNo,street,cityCandidate,pin));
				
				customer.add(cust);
			}
			return customer;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Customer> getAllCustomersNameStartsWith(String name) {
		GetConnection gc = new GetConnection();
		
		String sql ="SELECT * FROM Customer where cust_first_name LIKE ?";
		try {
			gc.ps = GetConnection.getOracleConn().prepareStatement(sql);
			gc.ps.setString(1, name);
			
			gc.rs = gc.ps.executeQuery();
			ArrayList<Customer> customer = new ArrayList<Customer>();
			
			while(gc.rs.next()){
				
				Customer cust = new Customer();
				cust.setCustId(gc.rs.getInt(1));
				cust.setName(cust.new Name(gc.rs.getString(2),gc.rs.getString(3)));
				cust.setIncome(gc.rs.getDouble(4));
				cust.setEmail(gc.rs.getString(5));
				
				int hNo = gc.rs.getInt(6);
				String street = gc.rs.getString(7);
				String cityCandidate = gc.rs.getString(8);
				int pin = gc.rs.getInt(9);
				
				cust.setAddr(cust.new Address(hNo,street,cityCandidate,pin));
				
				customer.add(cust);
			}
			return customer;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Customer> getAllCustomersWithoutCity() {
		GetConnection gc = new GetConnection();
		
		String sql ="SELECT * FROM Customer WHERE cust_first_name city IS NULL";
		try {
			gc.ps = GetConnection.getOracleConn().prepareStatement(sql);
			gc.rs = gc.ps.executeQuery();
			ArrayList<Customer> customer = new ArrayList<Customer>();
			
			while(gc.rs.next()){
				
				Customer cust = new Customer();
				cust.setCustId(gc.rs.getInt(1));
				cust.setName(cust.new Name(gc.rs.getString(2),gc.rs.getString(3)));
				cust.setIncome(gc.rs.getDouble(4));
				cust.setEmail(gc.rs.getString(5));
				
				int hNo = gc.rs.getInt(6);
				String street = gc.rs.getString(7);
				String cityCandidate = gc.rs.getString(8);
				int pin = gc.rs.getInt(9);
				
				cust.setAddr(cust.new Address(hNo,street,cityCandidate,pin));
				
				customer.add(cust);
			}
			return customer;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		GetConnection gc = new GetConnection();
		
		String sql ="SELECT * FROM Customer";
		try {
			gc.ps = GetConnection.getOracleConn().prepareStatement(sql);
			gc.rs = gc.ps.executeQuery();
			ArrayList<Customer> customer = new ArrayList<Customer>();
			
			while(gc.rs.next()){
				
				Customer cust = new Customer();
				cust.setCustId(gc.rs.getInt(1));
				cust.setName(cust.new Name(gc.rs.getString(2),gc.rs.getString(3)));
				cust.setIncome(gc.rs.getDouble(4));
				cust.setEmail(gc.rs.getString(5));
				
				int hNo = gc.rs.getInt(6);
				String street = gc.rs.getString(7);
				String cityCandidate = gc.rs.getString(8);
				int pin = gc.rs.getInt(9);
				
				cust.setAddr(cust.new Address(hNo,street,cityCandidate,pin));
				
				customer.add(cust);
			}
			return customer;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

}
