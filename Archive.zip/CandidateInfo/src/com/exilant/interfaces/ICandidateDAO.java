package com.exilant.interfaces;

import java.util.List;

import com.exilant.beans.Customer;

public interface ICandidateDAO {
	List<Customer> getAllCustomersOfCity(String city);
	List<Customer> getAllCustomersNameStartsWith(String name);
	List<Customer> getAllCustomersWithoutCity();
	List<Customer> getAllCustomers();
}
