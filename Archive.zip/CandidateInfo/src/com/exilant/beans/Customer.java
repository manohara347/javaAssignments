package com.exilant.beans;

public class Customer {
	
	private int custId;
	private Name name;
	private double income;
	private Address addr;
	private String email;
	
	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getName() {
		return name.fName + name.lName;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public double getIncome() {
		return income;
	}

	public void setIncome(double income) {
		this.income = income;
	}

	public String getAddr() {
		return addr.city + addr.hNo + addr.street + addr.pin;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
  // Customer Name
	public class Name {
		
		String fName;
		String lName;
		public Name(String fName, String lName) {
			super();
			this.fName = fName;
			this.lName = lName;
		}
	}

	// Customer Address
	public class Address {
		
		int hNo;
		String street;
		String city;
		int pin;
		public Address(int hNo, String street, String city, int pin) {
			super();
			this.hNo = hNo;
			this.street = street;
			this.city = city;
			this.pin = pin;
		}
	}

	public Customer(){
		
	}

}
